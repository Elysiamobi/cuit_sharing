package com.login.bean;

public class tools {
	public static String change(String str){
		str=str.replace("<","&lt");
		str=str.replace(">","&gt");
		return str;
	}

}
