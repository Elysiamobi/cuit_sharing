package com.servlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.bean.MsgInfo;

public class addWord extends HttpServlet{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException{
		doPost(request,response);	
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException{
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		String title=request.getParameter("title");
		String content=request.getParameter("content");
		MsgInfo msginfo = new MsgInfo();
		msginfo.setTitle(title);
		msginfo.setContent(content);
		HttpSession session=request.getSession();
		ServletContext scx=session.getServletContext();
		ArrayList wordlist=(ArrayList)scx.getAttribute("wordlist");
		if(wordlist==null)
			wordlist=new ArrayList();
		wordlist.add(msginfo);
		scx.setAttribute("wordlist",wordlist);
		response.sendRedirect("show.jsp");
	}
}
