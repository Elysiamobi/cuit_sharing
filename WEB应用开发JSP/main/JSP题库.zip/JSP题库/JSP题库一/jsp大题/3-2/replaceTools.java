package com.bean;

public class replaceTools {
	public static String change(String str){
		str=str.replace("<","&lt;");
		str=str.replace(">","&gt;");
		return str;
	}
}
